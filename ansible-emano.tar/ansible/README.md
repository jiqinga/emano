#emano部署前准备

1.harbor镜像仓库启动

2.修改/etc/hosts文件 (如下:)
182.10.1.162 master1
182.10.1.163 master2
182.10.1.164 master3
182.10.1.165 work1
182.10.1.166 work2
182.10.1.167 work3
182.10.1.168 work4
182.10.1.169 work5
182.10.1.162 images   (harbor镜像库解析)

3.修改/etc/ansible/roles/docker-swarm/defaults/main.yml
swarm_master: '182.10.1.162'   (只需替此ip为master1 IP)

4.修改/etc/ansible/roles/nfs/defaults/main.yml
nfs_exports: 
  - /emano/pkg 182.10.1.0/24(insecure,rw,sync,no_subtree_check,no_root_squash)  (替换182.10.1.0网段为真实网段)

5.修改/etc/ansible/roles/emano/defaults/main.yml
vip: '182.10.1.99'   (keepalived vip地址)
eth: 'ens33'         (网卡名)
harbor_port: 'images:88'   (harbor镜像库地址,images对应上面hosts文件解析)
kibana: '182.10.1.162'     (此处填写集群中任意地址即可，推荐master1地址)
db2: '182.10.1.169'        (填写work5 IP地址)
work3: '182.10.1.167'      (填写work3 IP地址)
master3: '182.10.1.164'    (填写master3 IP地址)

6.主机测试
ansible  all  -m ping  (无报错即可)

7.开始部署
cd /etc/ansible  && ansible-playbook emano.yml    (等待执行完毕)

8.初始化nfvo，alarms库
docker service ls   (执行命令查看服务都正常运行后才可执行下放命令)
cd /etc/ansible  && ansible-playbook init.yml

9.访问
http://vip/emano

