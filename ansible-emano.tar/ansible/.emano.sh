#!/bin/bash
set -e
 docker node update --label-add role=emano master1
 docker node update --label-add role=emano master2
 docker node update --label-add role=nfvo master3
 docker node update --label-add role=nfvo work1
 docker node update --label-add role=nfvo work2
 docker node update --label-add role=db   work4
 docker node update --label-add role=db   work5
 docker node update --label-add role=alarms  work3
 docker node update --label-add type=cad1 master1
 docker node update --label-add type=cad2 master2
 docker node update --label-add type=cad3 master3
 docker node update --label-add type=cad4  work1
 docker node update --label-add type=cad5 work2
 docker node update --label-add type=cad6 work3
 docker node update --label-add type=cad7 work4
 docker node update --label-add type=cad8 work5
 
#部署emano-nfvo应用
 docker stack deploy -c /docker-swarm/nfvo/postgres.yml emano
 docker stack deploy -c /docker-swarm/nfvo/visualizer.yml emano
sleep 20
 docker stack deploy -c /docker-swarm/nfvo/cig.yml  cig
sleep 40
 docker stack deploy -c /docker-swarm/nfvo/auth.yml emano
sleep 12
 docker stack deploy -c /docker-swarm/nfvo/elk.yml emano
sleep 12
 docker stack deploy -c /docker-swarm/nfvo/nfvo.yml emano
sleep 12
 docker stack deploy -c /docker-swarm/nfvo/pkg.yml emano
sleep 12
 docker stack deploy -c /docker-swarm/nfvo/tosca.yml emano
sleep 12
 docker stack deploy  -c /docker-swarm/nfvo/sftp.yml emano
#部署emano-alarms应用
sleep 30
 docker stack deploy -c /docker-swarm/alarms/zookeeper.yml alarms
sleep 30
 docker stack deploy -c /docker-swarm/alarms/umc.yml alarms
sleep 20
 docker stack deploy -c /docker-swarm/nfvo/nginx.yml emano
