#!/bin/bash
for i in nfvo auth pkg
do
docker ps | grep $i &>/dev/null
if [ $? -eq 0 ];then
echo $i
docker exec -it `docker ps -q -f name=$i | head -1` rake db:migrate RAILS_ENV=production  &>/dev/null
docker exec -it `docker ps -q -f name=$i | head -1` rake db:seed RAILS_ENV=production    $>/dev/null
else
continue
fi
done
